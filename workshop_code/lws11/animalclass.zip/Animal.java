public class Animal
{
    private String food;

    public Animal()
    {
        this.food = "grass";
    }

    public Animal(String food)
    {
        this.food = food;
    }

    public String getFood()
    {
        return this.food;
    }

    public String toString()
    {
        return "Animal{" + "food=" + this.food +"}";
    }
}