public class Emu extends Animal
{
    private double speed;

    public Emu(double speed)
    {
        super("insects");
        this.speed = speed;
    }

    public double getSpeed()
    {
        return this.speed;
    }

    public String toString()
    {
        return "Emu{" + "food=" + super.getFood() + ", speed=" + this.speed + "}";
    }
}