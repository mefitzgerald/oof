public class Koala extends Animal
{
    private int sleep;

    public Koala(String food, int sleep)
    {
        super(food);
        this.sleep = sleep;
    }

    public double getSleep()
    {
        return this.sleep;
    }

    public String toString()
    {
        return "Koala{" +
                "food=" + super.getFood() +
                ", sleep=" + this.sleep +
                "}";
    }
}