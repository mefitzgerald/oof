public class AnimalDriver
{
    public static void main(String args[])
    {
        Animal[] animals = new Animal[10];

        Animal a = new Animal("fish");
        Emu e = new Emu(22.3);
        Koala k = new Koala("gum leaves", 7);

        //add to array
        animals[0] = a;
        animals[1] = e;
        animals[2] = k;

        //display array
        for (Animal animal : animals)
        {
            if (animal != null)
            {
                System.out.println(animal.toString());
            }
        }

        //display emu speed
        for (Animal animal : animals)
        {
            if (animal != null && animal.getClass().getName().equals("Emu"))
            {
                System.out.println("Emu speed = " + ((Emu) animal).getSpeed());
            }
        }
    }
}